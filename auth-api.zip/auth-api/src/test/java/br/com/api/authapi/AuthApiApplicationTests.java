package br.com.api.authapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuthApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
